from brain_games.games import brain_gcd
from brain_games.unreal_engine import run_game


def main():
    run_game(brain_gcd)
    
    
if __name__ == '__main__':
    main()
