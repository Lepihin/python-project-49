### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lepihin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lepihin/python-project-49/actions)

<a href="https://codeclimate.com/github/Lepihin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75005184b117fd89224a/maintainability" /></a>

[![asciicast](https://asciinema.org/a/H3e6pKW0XD8w88vaTNf2d0u73.svg)](https://asciinema.org/a/H3e6pKW0XD8w88vaTNf2d0u73)


[![asciicast](https://asciinema.org/a/CWy4neKaZCPJAkV7Wi4xoyrdH.svg)](https://asciinema.org/a/CWy4neKaZCPJAkV7Wi4xoyrdH)


[![asciicast](https://asciinema.org/a/EJWBFuTzzmyGrQxtOZ0vYfPar.svg)](https://asciinema.org/a/EJWBFuTzzmyGrQxtOZ0vYfPar)


[![asciicast](https://asciinema.org/a/j2oV7D1uWOQz9Swn2nlEfspS7.svg)](https://asciinema.org/a/j2oV7D1uWOQz9Swn2nlEfspS7)
