### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lepihin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lepihin/python-project-49/actions)

<a href="https://codeclimate.com/github/Lepihin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75005184b117fd89224a/maintainability" /></a>
