from brain_games.games import brain_calc
from brain_games.unreal_engine import run_game


def main():
    run_game(brain_calc)
    
    
if __name__ == '__main__':
    main()
